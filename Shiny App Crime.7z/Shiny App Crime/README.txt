This Repo contains source code and data for a web application which interactively visualizes US crime data.

https://sthobbs.shinyapps.io/USCrime

data/Data.R is the script I ran to download the data from the FBI's website.

The 'shiny' R package needs to be downloaded off CRAN to run the app locally.
 